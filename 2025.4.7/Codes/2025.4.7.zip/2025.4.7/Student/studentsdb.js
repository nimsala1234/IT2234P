let students = [
    {regNo:'2021ICT78', name:'Dinithi',gender:'female',age:23,course:'IT'},
    {regNo:'2021ICT1', name:'James',age:25,gender:'male',course:'IT'},
    {regNo:'2021ICT10', name:'Rica',age:28,gender:'male',course:'IT'},
    {regNo:'2021ICT14', name:'Erica',age:20,gender:'female',course:'IT'},
    {regNo:'2021ICT100', name:'Emily',age:18,gender:'female',course:'IT'}
]

module.exports = students;